//
//  ViewController.swift
//  tictactoe
//
//  Created by Erik Swanson on 2/19/18.
//  Copyright © 2018 Erik Swanson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var box1: UIButton!
    @IBOutlet weak var box2: UIButton!
    @IBOutlet weak var box3: UIButton!
    @IBOutlet weak var box4: UIButton!
    @IBOutlet weak var box5: UIButton!
    @IBOutlet weak var box6: UIButton!
    @IBOutlet weak var box7: UIButton!
    @IBOutlet weak var box8: UIButton!
    @IBOutlet weak var box9: UIButton!
    
    @IBOutlet weak var gameOverLabel: UILabel!
    
    var boxList: Array<UIButton> = []
    var currentTurn = "x"
    var turnNumber = 0
    var board = ["", "", "", "", "", "", "", "", ""]
    let winConditions = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]
    let corners = [0, 2, 6, 8]
    let edges = [1, 3, 5, 7]
    let middle = 4
    var players = 1
    var possibleWin: Array<Int> = []
    var cpuWin: Array<Int> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        boxList = [box1, box2, box3, box4, box5, box6, box7, box8, box9]
    }
    
    func switchTurn() {
        if currentTurn == "x" {
            currentTurn = "o"
            turnNumber += 1
            if players == 1 {
                checkCpuWin()
                cpuMove()
            }
        } else {
            currentTurn = "x"
            turnNumber += 1
            possibleWin = []
        }
    }
    
    func setBox(pos: Int, box: UIButton) {
        box.setTitle(currentTurn.uppercased(), for: .normal)
        box.isEnabled = false
        board[pos] = currentTurn
        checkWin()
        switchTurn()
        if turnNumber == 9 {
            gameOverLabel.text = "Game Over, It's a Tie!"
        }
    }
    
    func cpuMove() {
        if cpuWin.count != 0 {
            for box in cpuWin {
                if board[box] == "" {
                    setBox(pos: box, box: boxList[box])
                }
            }
        } else if possibleWin.count != 0 {
            for box in possibleWin {
                if board[box] == "" {
                    setBox(pos: box, box: boxList[box])
                }
            }
        } else if board[middle] == "" {
            setBox(pos: middle, box: boxList[middle])
        } else if board[middle] == "x" && turnNumber == 1 {
            setBox(pos: 0, box: boxList[0])
        } else {
            for box in edges {
                if board[box] == "" {
                    setBox(pos: box, box: boxList[box])
                    return
                }
            }
            for box in corners {
                if board[box] == "" {
                    setBox(pos: box, box: boxList[box])
                    return
                }
            }
        }
    }
    
    func convBoard() -> Array<Int> {
        var newBoard = [0, 0, 0, 0, 0, 0, 0, 0, 0]
        for boxNum in 0..<board.count {
            if board[boxNum] == currentTurn {
                newBoard[boxNum] = 1
            } else if board[boxNum] != "" {
                newBoard[boxNum] = 4
            }
        }
        return newBoard
    }
    
    func checkWin() {
        let winBoard: Array<Int> = convBoard()
        var same = 0
        for condition in winConditions {
            same = 0
            for pos in condition {
                same += winBoard[pos]
            }
            if same == 3 {
                for i in boxList {
                    i.isEnabled = false
                }
                gameOverLabel.text = "Game Over, \(currentTurn.uppercased())s Won!"
                return
            } else if same == 2 {
                possibleWin = condition
                return
            }
        }
    }
    
    func checkCpuWin() {
        let winBoard: Array<Int> = convBoard()
        var same = 0
        for condition in winConditions {
            same = 0
            for pos in condition {
                same += winBoard[pos]
            }
            if same == 2 {
                cpuWin = condition
            }
        }
    }
    
    @IBAction func setPlayer(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            players = 1
        } else {
            players = 2
        }
    }
    
    @IBAction func box1(_ sender: UIButton) {
        setBox(pos: 0, box: sender)
    }
    @IBAction func box2(_ sender: UIButton) {
        setBox(pos: 1, box: sender)
    }
    @IBAction func box3(_ sender: UIButton) {
        setBox(pos: 2, box: sender)
    }
    @IBAction func box4(_ sender: UIButton) {
        setBox(pos: 3, box: sender)
    }
    @IBAction func box5(_ sender: UIButton) {
        setBox(pos: 4, box: sender)
    }
    @IBAction func box6(_ sender: UIButton) {
        setBox(pos: 5, box: sender)
    }
    @IBAction func box7(_ sender: UIButton) {
        setBox(pos: 6, box: sender)
    }
    @IBAction func box8(_ sender: UIButton) {
        setBox(pos: 7, box: sender)
    }
    @IBAction func box9(_ sender: UIButton) {
        setBox(pos: 8, box: sender)
    }
    
    @IBAction func reset(_ sender: Any) {
        currentTurn = "x"
        board = ["", "", "", "", "", "", "", "", ""]
        turnNumber = 0
        for i in boxList {
            i.setTitle("", for: .normal)
            i.isEnabled = true
        }
        possibleWin = []
        cpuWin = []
        gameOverLabel.text = ""
    }
    
}

